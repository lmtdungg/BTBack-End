﻿using System;
using System.Linq;
using System.Text;
using System.Globalization;

class Program
{
    // Bật hiển thị tiếng Việt
    static void SetupConsole()
    {
        Console.OutputEncoding = Encoding.UTF8;
        CultureInfo.DefaultThreadCurrentCulture = new CultureInfo("vi-VN");
    }

    // Bài 1: Viết hàm tính tổng của tất cả các số chẵn trong một mảng
    static int SumEvenNumbers(int[] arr)
    {
        return arr.Where(x => x % 2 == 0).Sum();
    }

    // Bài 2: Viết hàm kiểm tra xem một số có phải là số nguyên tố hay không
    static bool IsPrime(int num)
    {
        if (num < 2) return false;
        for (int i = 2; i * i <= num; i++)
        {
            if (num % i == 0) return false;
        }
        return true;
    }

    static void PrintPrimeNumbers(int[] arr)
    {
        for (int i = 0; i < arr.Length; i++)
        {
            if (IsPrime(arr[i]))
            {
                Console.WriteLine($"Chỉ số: {i}, Giá trị: {arr[i]}");
            }
        }
    }

    // Bài 3: Viết hàm đếm số lượng số âm và số dương trong một mảng
    static void CountPosNegNumbers(int[] arr, out int posCount, out int negCount)
    {
        posCount = arr.Count(x => x > 0);
        negCount = arr.Count(x => x < 0);
    }

    // Bài 4: Viết hàm tìm số lớn thứ hai trong một mảng các số nguyên
    static int FindSecondLargest(int[] arr)
    {
        int max = int.MinValue, secondMax = int.MinValue;
        foreach (int num in arr)
        {
            if (num > max)
            {
                secondMax = max;
                max = num;
            }
            else if (num > secondMax && num < max)
            {
                secondMax = num;
            }
        }
        return secondMax;
    }

    // Bài 5: Viết hàm hoán vị hai số nguyên a và b
    static void Swap(ref int a, ref int b)
    {
        int temp = a;
        a = b;
        b = temp;
    }

    // Bài 6: Viết hàm sắp xếp mảng số thực theo chiều tăng dần
    static void SortArray(ref double[] arr)
    {
        Array.Sort(arr);
    }

    static void Main()
    {
        SetupConsole();

        // Nhập mảng
        Console.Write("Nhập số phần tử của mảng: ");
        int n = int.Parse(Console.ReadLine());
        int[] arr = new int[n];
        Console.WriteLine("Nhập các phần tử của mảng:");
        for (int i = 0; i < n; i++)
        {
            arr[i] = int.Parse(Console.ReadLine());
        }

        // Gọi các hàm đã viết để kiểm tra kết quả
        Console.WriteLine("Tổng các số chẵn: " + SumEvenNumbers(arr));
        Console.WriteLine("Các số nguyên tố trong mảng:");
        PrintPrimeNumbers(arr);

        CountPosNegNumbers(arr, out int posCount, out int negCount);
        Console.WriteLine($"Số lượng số dương: {posCount}, số lượng số âm: {negCount}");

        Console.WriteLine("Số lớn thứ hai trong mảng: " + FindSecondLargest(arr));

        Console.Write("Nhập hai số cần hoán vị: ");
        int a = int.Parse(Console.ReadLine());
        int b = int.Parse(Console.ReadLine());
        Swap(ref a, ref b);
        Console.WriteLine($"Sau hoán vị: a = {a}, b = {b}");

        Console.Write("Nhập số phần tử của mảng thực: ");
        int m = int.Parse(Console.ReadLine());
        double[] realArr = new double[m];
        Console.WriteLine("Nhập các phần tử:");
        for (int i = 0; i < m; i++)
        {
            realArr[i] = double.Parse(Console.ReadLine());
        }
        SortArray(ref realArr);
        Console.WriteLine("Mảng sau khi sắp xếp: " + string.Join(", ", realArr));
    }
}