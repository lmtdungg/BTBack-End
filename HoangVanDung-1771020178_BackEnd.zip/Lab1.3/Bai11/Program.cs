﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        SoPhuc A = new SoPhuc();
        SoPhuc B = new SoPhuc();

        A.Nhap("A");
        B.Nhap("B");

        int chon;
        do
        {
            Console.WriteLine("\n====== MENU ======");
            Console.WriteLine("1. Tính tổng A + B");
            Console.WriteLine("2. Tính hiệu A - B");
            Console.WriteLine("3. Tính tích A * B");
            Console.WriteLine("4. Tính thương A / B");
            Console.WriteLine("0. Thoát");
            Console.Write("Chọn chức năng: ");
            chon = int.Parse(Console.ReadLine());

            try
            {
                switch (chon)
                {
                    case 1:
                        SoPhuc tong = A.Cong(B);
                        tong.HienThi("Tổng A + B");
                        break;
                    case 2:
                        SoPhuc hieu = A.Tru(B);
                        hieu.HienThi("Hiệu A - B");
                        break;
                    case 3:
                        SoPhuc tich = A.Nhan(B);
                        tich.HienThi("Tích A * B");
                        break;
                    case 4:
                        SoPhuc thuong = A.Chia(B);
                        thuong.HienThi("Thương A / B");
                        break;
                    case 0:
                        Console.WriteLine("Kết thúc chương trình.");
                        break;
                    default:
                        Console.WriteLine("Lựa chọn không hợp lệ!");
                        break;
                }
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine($"Lỗi chia: {ex.Message}");
            }

        } while (chon != 0);
    }
}
