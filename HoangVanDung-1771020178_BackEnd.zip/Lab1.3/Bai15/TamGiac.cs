﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class TamGiac : DaGiac
{
    public TamGiac()
    {
        SoCanh = 3;
        KichThuoc = new int[3];
    }

    public override void Nhap()
    {
        Console.WriteLine("Nhập thông tin tam giác:");
        for (int i = 0; i < 3; i++)
        {
            Console.Write($"Nhập cạnh thứ {i + 1}: ");
            KichThuoc[i] = int.Parse(Console.ReadLine());
        }
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Chu vi: {TinhChuVi()}");
        Console.WriteLine($"Diện tích: {TinhDienTich():0.00}");
        Console.WriteLine($"Có phải tam giác vuông? {(LaTamGiacVuong() ? "Có" : "Không")}");
    }

    public double TinhDienTich()
    {
        double a = KichThuoc[0], b = KichThuoc[1], c = KichThuoc[2];
        double p = (a + b + c) / 2;
        return Math.Sqrt(p * (p - a) * (p - b) * (p - c));
    }

    public bool LaTamGiacVuong()
    {
        Array.Sort(KichThuoc);
        int a = KichThuoc[0], b = KichThuoc[1], c = KichThuoc[2];
        return c * c == a * a + b * b;
    }

    public override int TinhChuVi()
    {
        return base.TinhChuVi();
    }
}
