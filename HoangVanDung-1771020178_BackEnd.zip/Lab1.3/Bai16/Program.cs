﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        QLTamGiac ql = new QLTamGiac();
        int chon;

        do
        {
            Console.WriteLine("\n=== MENU ===");
            Console.WriteLine("1. Nhập danh sách tam giác");
            Console.WriteLine("2. Hiển thị các tam giác và các phép tính");
            Console.WriteLine("3. Tổng chu vi và diện tích các tam giác");
            Console.WriteLine("0. Thoát");
            Console.Write("Chọn: ");
            chon = int.Parse(Console.ReadLine());

            switch (chon)
            {
                case 1:
                    ql.NhapDS();
                    break;
                case 2:
                    ql.HienThiDS();
                    break;
                case 3:
                    ql.TinhTongChuViVaDienTich();
                    break;
                case 0:
                    Console.WriteLine("Đã thoát chương trình.");
                    break;
                default:
                    Console.WriteLine("Lựa chọn không hợp lệ.");
                    break;
            }
        } while (chon != 0);
    }
}
