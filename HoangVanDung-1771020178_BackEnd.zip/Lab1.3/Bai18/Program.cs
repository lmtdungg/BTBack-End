﻿using System;
using System.Text;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        QuanLyCoQuan ql = new QuanLyCoQuan();
        int chon;

        do
        {
            Console.WriteLine("\n===== MENU =====");
            Console.WriteLine("1. Nhập danh sách cán bộ");
            Console.WriteLine("2. Hiển thị cán bộ thuộc Phòng tài chính");
            Console.WriteLine("3. Tìm kiếm theo họ tên");
            Console.WriteLine("0. Thoát");
            Console.Write("Chọn: ");
            chon = int.Parse(Console.ReadLine());

            switch (chon)
            {
                case 1:
                    ql.Nhap();
                    break;
                case 2:
                    ql.HienThiTheoDonVi("Phòng tài chính");
                    break;
                case 3:
                    Console.Write("Nhập họ tên cần tìm: ");
                    string hoTen = Console.ReadLine();
                    ql.TimTheoHoTen(hoTen);
                    break;
                case 0:
                    Console.WriteLine("Kết thúc chương trình.");
                    break;
                default:
                    Console.WriteLine("Lựa chọn không hợp lệ.");
                    break;
            }

        } while (chon != 0);
    }
}
