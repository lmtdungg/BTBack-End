﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class QuanLyCoQuan
{
    private List<CoQuan> danhSach = new List<CoQuan>();

    public void Nhap()
    {
        Console.Write("Nhập số lượng cán bộ: ");
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"\nNhập thông tin cán bộ thứ {i + 1}:");
            Console.Write("Họ tên: ");
            string hoTen = Console.ReadLine();
            Console.Write("Giới tính (nam/nữ): ");
            bool gioiTinh = Console.ReadLine().Trim().ToLower() == "nam";
            Console.Write("Tuổi: ");
            int tuoi = int.Parse(Console.ReadLine());
            Console.Write("Đơn vị công tác: ");
            string donVi = Console.ReadLine();
            Console.Write("Hệ số lương: ");
            double heSoLuong = double.Parse(Console.ReadLine());

            danhSach.Add(new CoQuan(hoTen, gioiTinh, tuoi, donVi, heSoLuong));
        }
    }

    public void HienThiTheoDonVi(string donVi)
    {
        var ketQua = danhSach.Where(x => x.DonVi.ToLower() == donVi.ToLower()).ToList();
        if (ketQua.Count == 0)
        {
            Console.WriteLine("Không có cán bộ nào thuộc đơn vị này.");
        }
        else
        {
            Console.WriteLine($"\nDanh sách cán bộ thuộc đơn vị: {donVi}");
            foreach (var item in ketQua)
                item.In();
        }
    }

    public void TimTheoHoTen(string hoTen)
    {
        var ketQua = danhSach.Where(x => x.HoTen.ToLower().Contains(hoTen.ToLower())).ToList();
        if (ketQua.Count == 0)
        {
            Console.WriteLine("Không tìm thấy cá nhân nào.");
        }
        else
        {
            Console.WriteLine("\nThông tin các cá nhân tìm được:");
            foreach (var item in ketQua)
                item.In();
        }
    }
}
