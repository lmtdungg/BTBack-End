﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class HoiVien
{
    public string HoTen { get; set; }
    public string DiaChi { get; set; }

    public HoiVien() { }

    public HoiVien(string hoTen, string diaChi)
    {
        HoTen = hoTen;
        DiaChi = diaChi;
    }

    public virtual void Nhap()
    {
        Console.Write("Nhập họ tên: ");
        HoTen = Console.ReadLine();
        Console.Write("Nhập địa chỉ: ");
        DiaChi = Console.ReadLine();
    }

    public virtual void Xuat()
    {
        Console.WriteLine($"Họ tên: {HoTen}, Địa chỉ: {DiaChi}");
    }
}
