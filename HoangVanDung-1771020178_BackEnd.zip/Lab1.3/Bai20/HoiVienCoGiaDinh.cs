﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class HoiVienCoGiaDinh : HoiVien
{
    public string TenVoChong { get; set; }
    public DateTime NgayCuoi { get; set; }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhập tên vợ/chồng: ");
        TenVoChong = Console.ReadLine();
        Console.Write("Nhập ngày cưới (dd/MM/yyyy): ");
        NgayCuoi = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy", null);
    }

    public override void Xuat()
    {
        base.Xuat();
        Console.WriteLine($"Vợ/Chồng: {TenVoChong}, Ngày cưới: {NgayCuoi:dd/MM/yyyy}");
    }
}
