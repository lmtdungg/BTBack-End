﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class KhachHang
{
    public string HoTen { get; set; }
    public string SoNha { get; set; }
    public string MaSoCongTo { get; set; }

    public void Nhap()
    {
        Console.Write("Nhập họ tên chủ hộ: ");
        HoTen = Console.ReadLine();
        Console.Write("Nhập số nhà: ");
        SoNha = Console.ReadLine();
        Console.Write("Nhập mã số công tơ: ");
        MaSoCongTo = Console.ReadLine();
    }

    public void HienThi()
    {
        Console.WriteLine($"Họ tên: {HoTen}, Số nhà: {SoNha}, Mã số công tơ: {MaSoCongTo}");
    }
}

