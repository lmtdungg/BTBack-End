﻿using System;
using System.Text;

class ChuongTrinh
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;

        // Bài 1: Viết chương trình nhập vào tên và tuổi, sau đó in ra màn hình thông báo "Xin chào [tên], bạn [tuổi] tuổi!".
        Console.Write("Nhap ten: ");
        string ten = Console.ReadLine();
        Console.Write("Nhap tuoi: ");
        int tuoi = int.Parse(Console.ReadLine());
        Console.WriteLine($"Xin chao {ten}, ban {tuoi} tuoi!");

        // Bài 2: Viết chương trình tính diện tích của hình chữ nhật khi người dùng nhập chiều dài và chiều rộng.
        Console.Write("Nhap chieu dai: ");
        double chieuDai = double.Parse(Console.ReadLine());
        Console.Write("Nhap chieu rong: ");
        double chieuRong = double.Parse(Console.ReadLine());
        Console.WriteLine($"Dien tich hinh chu nhat: {chieuDai * chieuRong}");

        // Bài 3: Viết chương trình chuyển đổi nhiệt độ từ độ C sang độ F
        // Công thức: F = (C * 9/5) + 32
        Console.Write("Nhap nhiet do (°C): ");
        double doC = double.Parse(Console.ReadLine());
        double doF = (doC * 9 / 5) + 32;
        Console.WriteLine($"Nhiet do (°F): {doF}");

        // Bài 4: Viết chương trình nhập vào một số nguyên và kiểm tra xem số đó có phải là số chẵn hay không.
        Console.Write("Nhap so nguyen: ");
        int soNguyen = int.Parse(Console.ReadLine());
        Console.WriteLine(soNguyen % 2 == 0 ? "So chan" : "So le");

        // Bài 5: Viết chương trình tính tổng và tích của hai số nhập từ bàn phím.
        Console.Write("Nhap so thu nhat: ");
        int so1 = int.Parse(Console.ReadLine());
        Console.Write("Nhap so thu hai: ");
        int so2 = int.Parse(Console.ReadLine());
        Console.WriteLine($"Tong: {so1 + so2}, Tich: {so1 * so2}");

        // Bài 6: Viết chương trình kiểm tra xem một số nhập vào có phải là số dương, số âm hay số không.
        Console.Write("Nhap mot so: ");
        int so = int.Parse(Console.ReadLine());
        if (so > 0) Console.WriteLine("So duong");
        else if (so < 0) Console.WriteLine("So am");
        else Console.WriteLine("So khong");

        // Bài 7: Viết chương trình kiểm tra xem một năm nhập vào có phải là năm nhuận hay không.
        Console.Write("Nhap nam: ");
        int nam = int.Parse(Console.ReadLine());
        bool laNamNhuan = (nam % 4 == 0 && nam % 100 != 0) || (nam % 400 == 0);
        Console.WriteLine(laNamNhuan ? "Nam nhuan" : "Khong phai nam nhuan");

        // Bài 8: Viết chương trình in ra bảng cửu chương từ 1 đến 10.
        for (int i = 1; i <= 10; i++)
        {
            for (int j = 1; j <= 10; j++)
            {
                Console.WriteLine($"{i} x {j} = {i * j}");
            }
            Console.WriteLine();
        }
        // Bài 9: Viết chương trình tính giai thừa của một số nguyên dương n.
        Console.Write("Nhap so nguyen duong n: ");
        int n = int.Parse(Console.ReadLine());
        long giaiThua = 1;
        for (int i = 1; i <= n; i++)
        {
            giaiThua *= i;
        }
        Console.WriteLine($"Giai thua cua {n} la {giaiThua}");

        // Bài 10: Viết chương trình kiểm tra xem một số có phải là số nguyên tố hay không.
        Console.Write("Nhap so can kiem tra: ");
        int kiemTraSNT = int.Parse(Console.ReadLine());
        bool laSoNguyenTo = kiemTraSNT > 1;
        for (int i = 2; i * i <= kiemTraSNT; i++)
        {
            if (kiemTraSNT % i == 0)
            {
                laSoNguyenTo = false;
                break;
            }
        }
        Console.WriteLine(laSoNguyenTo ? "So nguyen to" : "Khong phai so nguyen to");
    }
}

